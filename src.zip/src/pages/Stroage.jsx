const Stroage = () => {
  return <h1>Stroage</h1>;
};

export default Stroage;
